<?php
include 'dbconnection.php';
?>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <img src="images/bank_logo.png" width="50px" height="50px" style="margin-right:10px">
        <a class="navbar-brand" href="index.php" style="font-size:30px; text-align:right"><b> TSF co-oprative bank ltd</b></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent" style="float:left">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="margin:auto auto" >
                <li class="nav-item" style="margin-left: 50px;font-size:20px;">
                    <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                </li>
                <li class="nav-item" style="margin-left: 50px;font-size:20px;">
                    <a class="nav-link active" aria-current="page" href="about.php">About Us</a>
                </li>
                <li class="nav-item" style="margin-left: 50px;font-size:20px;">
                    <a class="nav-link active" aria-current="page" href="contact.php">Contact Us</a>
                </li>


        </div>
    </div>
</nav>